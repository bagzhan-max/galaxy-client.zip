# Galaxy Client — starter project

A clean, original Fabric client-side mod scaffold for Minecraft Java Edition 1.21.11, targeting use through Mojo Launcher on Android ARM64.

## Included in this starter

- Purple Galaxy HUD overlay
- FPS readout (F8)
- Coordinates (F7)
- Whole HUD toggle (F6)
- Sprint/status indicator
- Java 21 toolchain; no JNI or custom native library is loaded by this code

## Important ARM64 note

A Fabric mod JAR is Java bytecode and is not itself compiled specifically for ARM64. The Java code here avoids native dependencies, so it does not need an `arm64-v8a` `.so` file. Minecraft's renderer, LWJGL, and any other native runtime components are supplied by the Android launcher and must be compatible with the device. This starter has not been built or run inside Mojo Launcher yet.

## Build

Requires JDK 21 and internet access to download Gradle/Fabric/Minecraft dependencies.

```bash
gradle build
```

The remapped mod JAR should be produced under `build/libs/` (normally `galaxy-client-0.1.0.jar`). Copy that JAR into the Fabric `mods` folder for the Minecraft 1.21.11 instance in Mojo Launcher.

## Controls

- F6 — toggle entire HUD
- F7 — toggle coordinates
- F8 — toggle FPS

On Android, keybinds may require an attached keyboard or launcher-provided key mapping. Touch-friendly GUI controls are a planned next step.

## Scope

This is a starter, not a complete PvP client. It currently includes HUD/status utilities only; combat automation, aim assistance, packet manipulation, and other unfair-play features are intentionally not included. The custom ClickGUI, visual options, and further QoL modules can be added iteratively.

## ClickGUI
Press **Right Shift** in-game to open the purple Galaxy ClickGUI. It lets you toggle HUD, FPS, coordinates, and status. Press **Escape** or the Done button to close it. F6/F7/F8 remain quick toggles.
