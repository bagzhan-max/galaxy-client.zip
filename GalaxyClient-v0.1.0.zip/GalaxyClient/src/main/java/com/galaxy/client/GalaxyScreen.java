package com.galaxy.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Compact purple ClickGUI. Press Escape to close it. */
public final class GalaxyScreen extends Screen {
    public GalaxyScreen() { super(Text.literal("Galaxy Client")); }

    @Override
    protected void init() {
        int panelWidth = 300;
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(28, (this.height - 250) / 2);
        int buttonWidth = 128;
        int x1 = left + 16;
        int x2 = x1 + buttonWidth + 10;
        int y = top + 66;

        addDrawableChild(ButtonWidget.builder(label("HUD", GalaxyClient.hudEnabled), b -> {
            GalaxyClient.hudEnabled = !GalaxyClient.hudEnabled;
            b.setMessage(label("HUD", GalaxyClient.hudEnabled));
        }).dimensions(x1, y, buttonWidth, 24).build());
        addDrawableChild(ButtonWidget.builder(label("FPS Counter", GalaxyClient.fpsEnabled), b -> {
            GalaxyClient.fpsEnabled = !GalaxyClient.fpsEnabled;
            b.setMessage(label("FPS Counter", GalaxyClient.fpsEnabled));
        }).dimensions(x2, y, buttonWidth, 24).build());
        addDrawableChild(ButtonWidget.builder(label("Coordinates", GalaxyClient.coordinatesEnabled), b -> {
            GalaxyClient.coordinatesEnabled = !GalaxyClient.coordinatesEnabled;
            b.setMessage(label("Coordinates", GalaxyClient.coordinatesEnabled));
        }).dimensions(x1, y + 34, buttonWidth, 24).build());
        addDrawableChild(ButtonWidget.builder(label("Status", GalaxyClient.statusEnabled), b -> {
            GalaxyClient.statusEnabled = !GalaxyClient.statusEnabled;
            b.setMessage(label("Status", GalaxyClient.statusEnabled));
        }).dimensions(x2, y + 34, buttonWidth, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done  [ESC]"), b -> close())
                .dimensions(left + 78, y + 88, 144, 24).build());
    }

    private static Text label(String name, boolean enabled) {
        return Text.literal(name + "  " + (enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int panelWidth = 300;
        int panelHeight = 230;
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(28, (this.height - panelHeight) / 2);
        context.fill(left - 2, top - 2, left + panelWidth + 2, top + panelHeight + 2, 0xFFB56CFF);
        context.fill(left, top, left + panelWidth, top + panelHeight, 0xF20E0B18);
        context.fill(left, top, left + panelWidth, top + 42, 0xFF211334);
        context.fill(left, top + 41, left + panelWidth, top + 43, 0xFFB56CFF);
        context.drawText(textRenderer, "GALAXY CLIENT", left + 16, top + 10, 0xFFE2C4FF, true);
        context.drawText(textRenderer, "VISUALS  |  QOL  |  PVP  |  HUD", left + 16, top + 27, 0xFFB9A4D6, false);
        context.drawText(textRenderer, "Modules", left + 16, top + 52, 0xFFFFFFFF, true);
        super.render(context, mouseX, mouseY, delta);
        context.drawText(textRenderer, "Right Shift: menu  |  F6-F8: quick toggles", left + 16, top + 204, 0xFFB9A4D6, false);
    }

    @Override
    public boolean shouldPause() { return false; }
}
