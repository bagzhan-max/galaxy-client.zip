package com.galaxy.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

/** Galaxy Client: lightweight Java-only HUD and ClickGUI. */
public final class GalaxyClient implements ClientModInitializer {
    static final String MOD_ID = "galaxyclient";
    static final int PURPLE = 0xFFB56CFF;
    static final int PANEL = 0xE8141022;

    static boolean hudEnabled = true;
    static boolean coordinatesEnabled = true;
    static boolean fpsEnabled = true;
    static boolean statusEnabled = true;

    private static KeyBinding toggleHudKey;
    private static KeyBinding toggleCoordsKey;
    private static KeyBinding toggleFpsKey;
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        toggleHudKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.galaxyclient.toggle_hud", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F6,
                "category.galaxyclient"));
        toggleCoordsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.galaxyclient.toggle_coords", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F7,
                "category.galaxyclient"));
        toggleFpsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.galaxyclient.toggle_fps", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8,
                "category.galaxyclient"));
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.galaxyclient.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.galaxyclient"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleHudKey.wasPressed()) hudEnabled = !hudEnabled;
            while (toggleCoordsKey.wasPressed()) coordinatesEnabled = !coordinatesEnabled;
            while (toggleFpsKey.wasPressed()) fpsEnabled = !fpsEnabled;
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new GalaxyScreen());
            }
        });

        HudElementRegistry.addLast(Identifier.of(MOD_ID, "overlay"), (drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!hudEnabled || client.player == null || client.world == null || client.options.hudHidden) return;

            int x = 8, y = 8, width = 178;
            int lines = (fpsEnabled ? 1 : 0) + (coordinatesEnabled ? 1 : 0) + (statusEnabled ? 1 : 0);
            int height = 24 + lines * 12;
            drawContext.fill(x, y, x + width, y + height, PANEL);
            drawContext.fill(x, y, x + 3, y + height, PURPLE);
            drawContext.fill(x + 3, y, x + width, y + 1, 0xFF7040C0);
            drawContext.drawText(client.textRenderer, "✦ GALAXY CLIENT", x + 10, y + 6, PURPLE, true);
            int lineY = y + 20;
            if (fpsEnabled) {
                drawContext.drawText(client.textRenderer, "FPS  " + client.getCurrentFps(), x + 10, lineY, 0xFFFFFFFF, true);
                lineY += 12;
            }
            if (coordinatesEnabled) {
                var pos = client.player.getPos();
                String coords = String.format(java.util.Locale.ROOT, "XYZ  %.1f / %.1f / %.1f", pos.x, pos.y, pos.z);
                drawContext.drawText(client.textRenderer, coords, x + 10, lineY, 0xFFE8D9FF, true);
                lineY += 12;
            }
            if (statusEnabled) {
                String mode = client.player.isSprinting() ? "SPRINTING" : "READY";
                drawContext.drawText(client.textRenderer, "STATUS  " + mode, x + 10, lineY, 0xFFD8C4FF, true);
            }
        });
    }
}
